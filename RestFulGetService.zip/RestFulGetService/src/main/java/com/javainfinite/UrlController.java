package com.javainfinite;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.http.client.utils.URIBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;


@RestController
public class UrlController {
	
	@GetMapping("/javainfinite")
	public String homepage() {
		return "success";
	}
	
	@GetMapping("/javainfinite/{id}")
	public String pathVariableId(@PathVariable("id") Integer id) {
		return "Welcome to Java Infinite - id: "+id;
		
	}
	
	@GetMapping("/javainfinite/idParam")
	public String idParam(@RequestParam("id") Integer id) {
		return "Welcome to Java Infinite - Param ID: "+id;
	}
	
	@GetMapping("/javainfinite/params")
	public String multipleParams(@RequestParam("id") Integer id, @RequestParam("name") String name, @RequestParam("age") String age ) {
		return "Welcome to Java Infinite - Multiple Params - Id: "+id+" Name: "+name+" age: "+age;
	}
	
	@GetMapping("/javainfinite/uriComponentBuild")
	public String uriComponentBuild() {
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString("http://javainfinite.com");
		builder.queryParam("id", "1");
		builder.queryParam("One", "2");
		String url = builder.toUriString();
		return url;
	}
	
	@GetMapping("/javainfinite/uriBuild")
	public String formation() {
		String uriBuild = null;
		try {
			URIBuilder b = new URIBuilder("http://javainfinite.com");
			b.addParameter("one", "1");
			b.addParameter("two", "two");
			URL url = b.build().toURL();
			uriBuild = url.toString();
			
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return uriBuild;
	}

}
